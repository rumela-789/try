# Keep dictionary loading reflection-free classes as-is.
-keep class com.offlinetranslation.keyboard.translation.** { *; }
