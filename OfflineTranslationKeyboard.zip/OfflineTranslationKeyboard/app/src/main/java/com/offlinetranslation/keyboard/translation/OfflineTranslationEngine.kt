package com.offlinetranslation.keyboard.translation

import android.content.Context
import java.util.regex.Pattern

/**
 * MVP offline translation engine for Bangla <-> English.
 *
 * Strategy (in order):
 *  1. Exact-phrase match against the bundled phrase dictionary (covers common chat
 *     sentences like "how are you" / "তুমি কেমন আছো" with natural word order).
 *  2. Token-by-token dictionary substitution for anything not covered by a phrase,
 *     preserving punctuation and unknown words (proper nouns, slang, etc.) as-is so the
 *     user can still see and hand-correct the result rather than losing information.
 *
 * This is intentionally simple and fully deterministic so it can run instantly on any
 * device with no ML runtime and no bundled model weights. It is NOT a full neural machine
 * translation system. The TranslationEngine interface exists specifically so this class can
 * be swapped for a bundled on-device NMT model (e.g. a quantized TFLite seq2seq model) in a
 * later version without changing any caller (IME, ProcessText activity, etc).
 */
class OfflineTranslationEngine(private val context: Context) : TranslationEngine {

    private val tokenPattern = Pattern.compile("([\\p{L}\\p{M}]+|[^\\p{L}\\p{M}\\s]+|\\s+)")

    override fun isReady(): Boolean {
        val a = DictionaryLoader.load(context, Lang.BANGLA, Lang.ENGLISH)
        val b = DictionaryLoader.load(context, Lang.ENGLISH, Lang.BANGLA)
        return a != null && b != null
    }

    override fun detectLanguage(text: String): Lang = LanguageDetector.detect(text)

    override fun translate(text: String, targetLang: Lang?): TranslationResult {
        val trimmed = text.trim()
        val detected = detectLanguage(trimmed)
        val target = targetLang ?: Lang.other(detected)

        if (trimmed.isEmpty()) {
            return TranslationResult(text, "", detected, target)
        }

        val pack = DictionaryLoader.load(context, detected, target)
            ?: return TranslationResult(text, text, detected, target) // no pack -> passthrough

        // 1) Try a whole-phrase match (case/space-insensitive).
        val normalized = DictionaryLoader.normalize(trimmed)
        pack.phrases[normalized]?.let { phraseHit ->
            return TranslationResult(text, capitalizeIfEnglish(phraseHit, target), detected, target)
        }

        // 2) Fall back to token-by-token substitution, preserving punctuation/spacing/unknowns.
        val matcher = tokenPattern.matcher(trimmed)
        val out = StringBuilder()
        while (matcher.find()) {
            val token = matcher.group()
            if (token.isBlank()) {
                out.append(token)
                continue
            }
            val isWord = token.any { it.isLetter() }
            if (!isWord) {
                out.append(token) // punctuation / numbers pass through untouched
                continue
            }
            val lookupKey = DictionaryLoader.normalize(token)
            val translatedWord = pack.words[lookupKey]
            out.append(translatedWord ?: token) // unknown words are kept as-is, not dropped
        }

        val result = capitalizeIfEnglish(out.toString(), target)
        return TranslationResult(text, result, detected, target)
    }

    private fun capitalizeIfEnglish(s: String, target: Lang): String {
        if (target != Lang.ENGLISH) return s
        val trimmed = s.trimStart()
        if (trimmed.isEmpty()) return s
        val leadingSpaces = s.length - trimmed.length
        return s.substring(0, leadingSpaces) + trimmed.replaceFirstChar { it.uppercaseChar() }
    }
}
