package com.offlinetranslation.keyboard.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.offlinetranslation.keyboard.R
import com.offlinetranslation.keyboard.data.SettingsRepository

@Composable
fun KeyboardSettingsScreen() {
    val context = LocalContext.current
    val settings = remember { SettingsRepository(context) }

    var vibrate by remember { mutableStateOf(settings.vibrateOnKeyPress) }
    var sound by remember { mutableStateOf(settings.soundOnKeyPress) }
    var banglaDefault by remember { mutableStateOf(settings.defaultLayoutIsBangla) }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text(stringResource(R.string.keyboard_settings_title), style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))

        SettingSwitchRow(stringResource(R.string.pref_vibrate), vibrate) {
            vibrate = it; settings.vibrateOnKeyPress = it
        }
        SettingSwitchRow(stringResource(R.string.pref_sound), sound) {
            sound = it; settings.soundOnKeyPress = it
        }

        Spacer(Modifier.height(12.dp))
        Text(stringResource(R.string.pref_default_layout), style = MaterialTheme.typography.titleSmall)
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilterChip(
                selected = banglaDefault,
                onClick = { banglaDefault = true; settings.defaultLayoutIsBangla = true },
                label = { Text("বাংলা") }
            )
            Spacer(Modifier.width(8.dp))
            FilterChip(
                selected = !banglaDefault,
                onClick = { banglaDefault = false; settings.defaultLayoutIsBangla = false },
                label = { Text("English") }
            )
        }
    }
}

@Composable
fun SettingSwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
