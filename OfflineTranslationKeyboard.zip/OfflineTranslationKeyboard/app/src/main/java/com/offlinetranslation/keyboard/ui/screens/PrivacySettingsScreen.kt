package com.offlinetranslation.keyboard.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.offlinetranslation.keyboard.R

@Composable
fun PrivacySettingsScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(12.dp))
        Text(stringResource(R.string.privacy_title), style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        Text(stringResource(R.string.privacy_body), style = MaterialTheme.typography.bodyMedium)

        Spacer(Modifier.height(20.dp))
        listOf(
            "কোনো INTERNET পারমিশন এই অ্যাপে নেই — কোড লেভেলে নিশ্চিত করা।",
            "সব অনুবাদ ডিভাইসের মধ্যেই bundled dictionary দিয়ে করা হয়।",
            "কোনো keystroke logging বা analytics tracking নেই।",
            "সেটিংস শুধু স্থানীয়ভাবে (SharedPreferences) সংরক্ষিত হয়।"
        ).forEach {
            Row(Modifier.padding(vertical = 4.dp)) {
                Text("•  ", style = MaterialTheme.typography.bodyMedium)
                Text(it, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
