package com.offlinetranslation.keyboard.keyboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class KeyboardLayer { BANGLA_LETTERS, BANGLA_MATRA, ENGLISH, SYMBOLS, EMOJI }

private val KeyGap = 3.dp
private val KeyHeight = 46.dp

@Composable
fun KeyboardScreen(
    layer: KeyboardLayer,
    isTranslating: Boolean,
    onAction: (KeyAction) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 4.dp, vertical = 6.dp)
    ) {
        when (layer) {
            KeyboardLayer.BANGLA_LETTERS -> BanglaLettersLayer(onAction)
            KeyboardLayer.BANGLA_MATRA -> BanglaMatraLayer(onAction)
            KeyboardLayer.ENGLISH -> EnglishLettersLayer(onAction)
            KeyboardLayer.SYMBOLS -> SymbolsLayer(layer, onAction)
            KeyboardLayer.EMOJI -> EmojiLayer(onAction)
        }
        Spacer(Modifier.height(4.dp))
        FunctionRow(layer = layer, isTranslating = isTranslating, onAction = onAction)
    }
}

@Composable
private fun BanglaLettersLayer(onAction: (KeyAction) -> Unit) {
    KeyRowView(BanglaLayout.vowels, onAction)
    KeyRowView(BanglaLayout.consonantsRow1, onAction)
    KeyRowView(BanglaLayout.consonantsRow2, onAction)
    KeyRowView(BanglaLayout.consonantsRow3, onAction)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(KeyGap)) {
        BanglaLayout.consonantsRow4.forEach { KeyButton(it, Modifier.weight(1f), onAction) }
        KeyButton(
            KeyDef("␈", KeyAction.Backspace),
            Modifier.weight(1.6f),
            onAction,
            icon = Icons.Filled.Backspace
        )
    }
}

@Composable
private fun BanglaMatraLayer(onAction: (KeyAction) -> Unit) {
    KeyRowView(BanglaLayout.matras, onAction, keyHeight = 56.dp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(KeyGap)) {
        KeyButton(BanglaLayout.hasant, Modifier.weight(2f), onAction)
        KeyButton(
            KeyDef("অ আ (Letters)", KeyAction.ToggleMatraLayer),
            Modifier.weight(3f),
            onAction
        )
        KeyButton(
            KeyDef("␈", KeyAction.Backspace),
            Modifier.weight(1.6f),
            onAction,
            icon = Icons.Filled.Backspace
        )
    }
}

@Composable
private fun EnglishLettersLayer(onAction: (KeyAction) -> Unit) {
    KeyRowView(EnglishLayout.row1, onAction)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(KeyGap)
    ) {
        EnglishLayout.row2.forEach { KeyButton(it, Modifier.weight(1f), onAction) }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(KeyGap)) {
        EnglishLayout.row3.forEach { KeyButton(it, Modifier.weight(1f), onAction) }
        KeyButton(
            KeyDef("␈", KeyAction.Backspace),
            Modifier.weight(1.6f),
            onAction,
            icon = Icons.Filled.Backspace
        )
    }
}

@Composable
private fun SymbolsLayer(layer: KeyboardLayer, onAction: (KeyAction) -> Unit) {
    // Show Bangla digits if we came from a Bangla context is not tracked here; keep both
    // available by defaulting to the numeric row that matches the last active script isn't
    // known at this layer, so we show universal Arabic numerals + shared punctuation, which
    // reads correctly in either language.
    KeyRowView(EnglishLayout.numbers, onAction)
    KeyRowView(EnglishLayout.punctuation, onAction)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(KeyGap)) {
        KeyRowView(BanglaLayout.punctuation, onAction)
    }
}

@Composable
private fun EmojiLayer(onAction: (KeyAction) -> Unit) {
    val rows = EmojiLayout.grid.chunked(5)
    rows.forEach { row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(KeyGap)) {
            row.forEach { KeyButton(it, Modifier.weight(1f), onAction) }
        }
    }
}

@Composable
private fun FunctionRow(layer: KeyboardLayer, isTranslating: Boolean, onAction: (KeyAction) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(KeyGap)) {
        // Globe: cycle to another installed keyboard (standard Android IME switcher behaviour)
        SmallIconKey(Icons.Filled.Language, weight = 1f) { onAction(KeyAction.NextInputMethod) }

        // Layer toggles
        when (layer) {
            KeyboardLayer.SYMBOLS -> SmallTextKey("অআ/ABC", weight = 1.4f) { onAction(KeyAction.SwitchToLetters) }
            KeyboardLayer.BANGLA_LETTERS -> {
                SmallTextKey("কার", weight = 1.2f) { onAction(KeyAction.ToggleMatraLayer) }
                SmallTextKey("EN", weight = 1.2f) { onAction(KeyAction.SwitchToEnglish) }
            }
            KeyboardLayer.BANGLA_MATRA -> {
                SmallTextKey("EN", weight = 1.2f) { onAction(KeyAction.SwitchToEnglish) }
            }
            KeyboardLayer.ENGLISH -> {
                SmallTextKey("বাং", weight = 1.2f) { onAction(KeyAction.SwitchToBangla) }
            }
            KeyboardLayer.EMOJI -> {
                SmallTextKey("অআ/ABC", weight = 1.4f) { onAction(KeyAction.SwitchToLetters) }
            }
        }
        if (layer != KeyboardLayer.SYMBOLS) {
            SmallTextKey("?123", weight = 1.1f) { onAction(KeyAction.SwitchToSymbols) }
        }

        // Space bar
        KeyButton(
            KeyDef("Space", KeyAction.Space),
            Modifier.weight(3.2f),
            onAction
        )

        SmallIconKey(Icons.Filled.EmojiEmotions, weight = 1f) { onAction(KeyAction.SwitchToEmoji) }

        // Translate — the headline feature, visually accented
        TranslateKey(isTranslating = isTranslating, weight = 1.9f) { onAction(KeyAction.Translate) }

        SmallIconKey(Icons.AutoMirrored.Filled.KeyboardReturn, weight = 1.2f, accent = true) {
            onAction(KeyAction.Enter)
        }
    }
}

@Composable
private fun KeyRowView(row: KeyRow, onAction: (KeyAction) -> Unit, keyHeight: androidx.compose.ui.unit.Dp = KeyHeight) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(KeyGap)) {
        row.forEach { KeyButton(it, Modifier.weight(1f), onAction, height = keyHeight) }
    }
}

@Composable
private fun KeyButton(
    key: KeyDef,
    modifier: Modifier,
    onAction: (KeyAction) -> Unit,
    height: androidx.compose.ui.unit.Dp = KeyHeight,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
) {
    Box(
        modifier = modifier
            .height(height)
            .clip(RoundedCornerShape(6.dp))
            .background(if (key.isAccent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface)
            .clickable { onAction(key.action) },
        contentAlignment = Alignment.Center
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = key.label, tint = MaterialTheme.colorScheme.onSurface)
        } else {
            Text(
                text = key.label,
                fontSize = if (key.label.length > 2) 12.sp else 16.sp,
                textAlign = TextAlign.Center,
                color = if (key.isAccent) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun SmallTextKey(label: String, weight: Float, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .weight(weight)
            .height(KeyHeight)
            .clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.secondaryContainer)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
    }
}

@Composable
private fun SmallIconKey(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    weight: Float,
    accent: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .weight(weight)
            .height(KeyHeight)
            .clip(RoundedCornerShape(6.dp))
            .background(if (accent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = if (accent) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSecondaryContainer
        )
    }
}

@Composable
private fun TranslateKey(isTranslating: Boolean, weight: Float, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .weight(weight)
            .height(KeyHeight)
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF0F9D58))
            .clickable(enabled = !isTranslating) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Translate, contentDescription = "Translate", tint = Color.White)
            Spacer(Modifier.width(2.dp))
            Text(
                if (isTranslating) "…" else "🌐",
                color = Color.White,
                fontSize = 12.sp
            )
        }
    }
}
