package com.offlinetranslation.keyboard.data

import android.content.Context
import com.offlinetranslation.keyboard.translation.Lang

/**
 * All settings are stored locally in a private SharedPreferences file. Nothing here is ever
 * synced to a server. (See AndroidManifest — the app declares no INTERNET permission at all.)
 */
class SettingsRepository(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("offline_translation_prefs", Context.MODE_PRIVATE)

    var vibrateOnKeyPress: Boolean
        get() = prefs.getBoolean(KEY_VIBRATE, true)
        set(value) = prefs.edit().putBoolean(KEY_VIBRATE, value).apply()

    var soundOnKeyPress: Boolean
        get() = prefs.getBoolean(KEY_SOUND, false)
        set(value) = prefs.edit().putBoolean(KEY_SOUND, value).apply()

    var defaultLayoutIsBangla: Boolean
        get() = prefs.getBoolean(KEY_DEFAULT_LAYOUT_BN, true)
        set(value) = prefs.edit().putBoolean(KEY_DEFAULT_LAYOUT_BN, value).apply()

    var autoDetectLanguage: Boolean
        get() = prefs.getBoolean(KEY_AUTO_DETECT, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_DETECT, value).apply()

    var autoInsertTranslation: Boolean
        get() = prefs.getBoolean(KEY_AUTO_INSERT, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_INSERT, value).apply()

    var showOriginalAndTranslated: Boolean
        get() = prefs.getBoolean(KEY_SHOW_ORIGINAL, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_ORIGINAL, value).apply()

    var defaultTargetLang: Lang
        get() = Lang.fromCode(prefs.getString(KEY_DEFAULT_TARGET, Lang.ENGLISH.code) ?: Lang.ENGLISH.code)
        set(value) = prefs.edit().putString(KEY_DEFAULT_TARGET, value.code).apply()

    companion object {
        private const val KEY_VIBRATE = "vibrate_on_key"
        private const val KEY_SOUND = "sound_on_key"
        private const val KEY_DEFAULT_LAYOUT_BN = "default_layout_bangla"
        private const val KEY_AUTO_DETECT = "auto_detect_language"
        private const val KEY_AUTO_INSERT = "auto_insert_translation"
        private const val KEY_SHOW_ORIGINAL = "show_original_and_translated"
        private const val KEY_DEFAULT_TARGET = "default_target_lang"
    }
}
