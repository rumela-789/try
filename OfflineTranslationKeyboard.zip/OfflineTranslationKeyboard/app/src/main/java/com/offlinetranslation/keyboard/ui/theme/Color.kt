package com.offlinetranslation.keyboard.ui.theme

import androidx.compose.ui.graphics.Color

val BrandGreen = Color(0xFF0F9D58)
val BrandGreenDark = Color(0xFF0B7A45)
val BrandSurfaceLight = Color(0xFFF7F9F8)
val BrandSurfaceDark = Color(0xFF121212)
