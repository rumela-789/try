package com.offlinetranslation.keyboard.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.offlinetranslation.keyboard.R
import com.offlinetranslation.keyboard.data.SettingsRepository
import com.offlinetranslation.keyboard.translation.Lang

@Composable
fun TranslationSettingsScreen() {
    val context = LocalContext.current
    val settings = remember { SettingsRepository(context) }

    var autoDetect by remember { mutableStateOf(settings.autoDetectLanguage) }
    var autoInsert by remember { mutableStateOf(settings.autoInsertTranslation) }
    var showOriginal by remember { mutableStateOf(settings.showOriginalAndTranslated) }
    var target by remember { mutableStateOf(settings.defaultTargetLang) }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text(stringResource(R.string.translation_settings_title), style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))

        SettingSwitchRow(stringResource(R.string.pref_auto_detect), autoDetect) {
            autoDetect = it; settings.autoDetectLanguage = it
        }
        SettingSwitchRow(stringResource(R.string.pref_auto_insert), autoInsert) {
            autoInsert = it; settings.autoInsertTranslation = it
        }
        SettingSwitchRow(stringResource(R.string.pref_show_original), showOriginal) {
            showOriginal = it; settings.showOriginalAndTranslated = it
        }

        if (!autoDetect) {
            Spacer(Modifier.height(12.dp))
            Text(stringResource(R.string.pref_default_target), style = MaterialTheme.typography.titleSmall)
            Row {
                Lang.entries.forEach { lang ->
                    FilterChip(
                        selected = target == lang,
                        onClick = { target = lang; settings.defaultTargetLang = lang },
                        label = { Text(lang.displayName) },
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
            }
        }
    }
}
