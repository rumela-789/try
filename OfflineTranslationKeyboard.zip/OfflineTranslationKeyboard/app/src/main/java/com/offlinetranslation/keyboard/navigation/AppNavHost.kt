package com.offlinetranslation.keyboard.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.offlinetranslation.keyboard.R
import com.offlinetranslation.keyboard.ui.screens.HomeScreen
import com.offlinetranslation.keyboard.ui.screens.KeyboardSettingsScreen
import com.offlinetranslation.keyboard.ui.screens.LanguageModelsScreen
import com.offlinetranslation.keyboard.ui.screens.PrivacySettingsScreen
import com.offlinetranslation.keyboard.ui.screens.TranslationSettingsScreen

private sealed class Dest(val route: String, val labelRes: Int, val icon: ImageVector) {
    object Home : Dest("home", R.string.nav_home, Icons.Filled.Home)
    object Languages : Dest("languages", R.string.nav_languages, Icons.Filled.Language)
    object Keyboard : Dest("keyboard", R.string.nav_keyboard, Icons.Filled.Keyboard)
    object Translation : Dest("translation", R.string.nav_translation, Icons.Filled.Translate)
    object Privacy : Dest("privacy", R.string.nav_privacy, Icons.Filled.Lock)
}

private val destinations = listOf(Dest.Home, Dest.Languages, Dest.Keyboard, Dest.Translation, Dest.Privacy)

@Composable
fun AppNavHost() {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            NavigationBar {
                val backStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = backStackEntry?.destination
                destinations.forEach { dest ->
                    NavigationBarItem(
                        selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true,
                        onClick = {
                            navController.navigate(dest.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(dest.icon, contentDescription = null) },
                        label = { Text(stringResource(dest.labelRes)) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Dest.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Dest.Home.route) { HomeScreen() }
            composable(Dest.Languages.route) { LanguageModelsScreen() }
            composable(Dest.Keyboard.route) { KeyboardSettingsScreen() }
            composable(Dest.Translation.route) { TranslationSettingsScreen() }
            composable(Dest.Privacy.route) { PrivacySettingsScreen() }
        }
    }
}
