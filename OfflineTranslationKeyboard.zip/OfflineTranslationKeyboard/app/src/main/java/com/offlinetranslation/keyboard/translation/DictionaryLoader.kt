package com.offlinetranslation.keyboard.translation

import android.content.Context
import org.json.JSONObject

data class LanguagePackDictionary(
    val sourceLang: Lang,
    val targetLang: Lang,
    val phrases: Map<String, String>,
    val words: Map<String, String>,
)

/**
 * Reads dictionary packs from /assets/dictionaries/*.json.
 * These files ship inside the APK itself (bundled offline resources) — nothing is
 * downloaded at runtime for the bn<->en pair. Future language packs can either also be
 * bundled here, or added later as downloadable asset packs managed from the
 * "Download/Manage Offline Language Models" screen, without changing this loader's contract.
 */
object DictionaryLoader {

    private val cache = mutableMapOf<String, LanguagePackDictionary>()

    fun load(context: Context, sourceLang: Lang, targetLang: Lang): LanguagePackDictionary? {
        val key = "${sourceLang.code}_${targetLang.code}"
        cache[key]?.let { return it }

        val fileName = "dictionaries/$key.json"
        return try {
            val json = context.assets.open(fileName).bufferedReader().use { it.readText() }
            val root = JSONObject(json)

            val phrases = mutableMapOf<String, String>()
            root.optJSONObject("phrases")?.let { obj ->
                obj.keys().forEach { k -> phrases[normalize(k)] = obj.getString(k) }
            }

            val words = mutableMapOf<String, String>()
            root.optJSONObject("words")?.let { obj ->
                obj.keys().forEach { k -> words[normalize(k)] = obj.getString(k) }
            }

            val pack = LanguagePackDictionary(sourceLang, targetLang, phrases, words)
            cache[key] = pack
            pack
        } catch (e: Exception) {
            null
        }
    }

    fun normalize(s: String): String = s.trim().lowercase()
}
