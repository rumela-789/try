package com.offlinetranslation.keyboard.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.offlinetranslation.keyboard.R

private data class LangPackUi(val title: String, val installed: Boolean)

@Composable
fun LanguageModelsScreen() {
    val bundled = LangPackUi(stringResource(R.string.lang_bn_en), installed = true)
    val comingSoon = listOf("English ↔ हिन्दी (Hindi)", "English ↔ العربية (Arabic)", "English ↔ Español (Spanish)", "English ↔ Français (French)")

    Column(
        Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {
        Text(stringResource(R.string.languages_title), style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))

        LanguagePackRow(bundled.title, stringResource(R.string.lang_bn_en_status_installed), installed = true)

        Spacer(Modifier.height(20.dp))
        Text("ভবিষ্যতের ভাষা (Coming soon)", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        comingSoon.forEach {
            LanguagePackRow(it, stringResource(R.string.lang_coming_soon), installed = false)
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun LanguagePackRow(title: String, status: String, installed: Boolean) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (installed) Icons.Filled.CheckCircle else Icons.Filled.CloudOff,
                contentDescription = null,
                tint = if (installed) Color(0xFF0F9D58) else MaterialTheme.colorScheme.outline
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
