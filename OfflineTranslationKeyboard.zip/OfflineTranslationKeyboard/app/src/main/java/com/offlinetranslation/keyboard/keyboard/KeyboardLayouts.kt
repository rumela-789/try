package com.offlinetranslation.keyboard.keyboard

/** What happens when a key is tapped. */
sealed class KeyAction {
    data class InsertText(val text: String) : KeyAction()
    object Backspace : KeyAction()
    object Enter : KeyAction()
    object Space : KeyAction()
    object ShiftLayer : KeyAction()      // reserved for future use
    object ToggleMatraLayer : KeyAction() // switch between Bangla letters layer and কার/মাত্রা layer
    object SwitchToEnglish : KeyAction()
    object SwitchToBangla : KeyAction()
    object SwitchToSymbols : KeyAction()
    object SwitchToLetters : KeyAction()
    object SwitchToEmoji : KeyAction()
    object Translate : KeyAction()
    object NextInputMethod : KeyAction() // globe key: cycle to another installed keyboard
}

/** A single key on the keyboard. [label] is what is drawn, [action] is what it does. */
data class KeyDef(
    val label: String,
    val action: KeyAction,
    val weight: Float = 1f,       // relative width in its row
    val isAccent: Boolean = false // visually highlighted (e.g. Translate, Enter)
)

/** A full keyboard is a list of rows of keys. */
typealias KeyRow = List<KeyDef>

object BanglaLayout {

    // স্বরবর্ণ — independent vowels
    val vowels: KeyRow = listOf(
        "অ", "আ", "ই", "ঈ", "উ", "ঊ", "এ", "ঐ", "ও", "ঔ"
    ).map { KeyDef(it, KeyAction.InsertText(it)) }

    // ব্যঞ্জনবর্ণ — consonants, 4 rows as specified
    val consonantsRow1: KeyRow = listOf("ক", "খ", "গ", "ঘ", "ঙ", "চ", "ছ", "জ", "ঝ", "ঞ")
        .map { KeyDef(it, KeyAction.InsertText(it)) }
    val consonantsRow2: KeyRow = listOf("ট", "ঠ", "ড", "ঢ", "ণ", "ত", "থ", "দ", "ধ", "ন")
        .map { KeyDef(it, KeyAction.InsertText(it)) }
    val consonantsRow3: KeyRow = listOf("প", "ফ", "ব", "ভ", "ম", "য", "র", "ল", "শ", "ষ")
        .map { KeyDef(it, KeyAction.InsertText(it)) }
    val consonantsRow4: KeyRow = listOf("স", "হ", "ড়", "ঢ়", "য়", "ং", "ঃ", "ঁ")
        .map { KeyDef(it, KeyAction.InsertText(it)) }

    // কার/মাত্রা — dependent vowel signs, shown on their own selectable layer
    val matras: KeyRow = listOf(
        "া" to "আ", "ি" to "ই", "ী" to "ঈ", "ু" to "উ",
        "ূ" to "ঊ", "ে" to "এ", "ৈ" to "ঐ", "ো" to "ও", "ৌ" to "ঔ"
    ).map { (mark, label) -> KeyDef("$label\n$mark", KeyAction.InsertText(mark)) }

    val hasant = KeyDef("্ (হসন্ত)", KeyAction.InsertText("্"))

    val numbers: KeyRow = listOf("১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "০")
        .map { KeyDef(it, KeyAction.InsertText(it)) }

    val punctuation: KeyRow = listOf("।", ",", "?", "!", "\"", "-", ":", ";", "(", ")")
        .map { KeyDef(it, KeyAction.InsertText(it)) }
}

object EnglishLayout {
    val row1: KeyRow = "QWERTYUIOP".map { KeyDef(it.toString(), KeyAction.InsertText(it.toString())) }
    val row2: KeyRow = "ASDFGHJKL".map { KeyDef(it.toString(), KeyAction.InsertText(it.toString())) }
    val row3: KeyRow = "ZXCVBNM".map { KeyDef(it.toString(), KeyAction.InsertText(it.toString())) }

    val numbers: KeyRow = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
        .map { KeyDef(it, KeyAction.InsertText(it)) }

    val punctuation: KeyRow = listOf(".", ",", "?", "!", "\"", "-", ":", ";", "(", ")")
        .map { KeyDef(it, KeyAction.InsertText(it)) }
}

/** Common emoji strip shown on the emoji layer, available from either language layout. */
object EmojiLayout {
    val grid: KeyRow = listOf(
        "😀", "😂", "😍", "😊", "😢", "😡", "👍", "👎", "🙏", "❤️",
        "🔥", "🎉", "😴", "🤔", "😅", "🙌", "👏", "😎", "💯", "✅"
    ).map { KeyDef(it, KeyAction.InsertText(it)) }
}
