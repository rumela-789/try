package com.offlinetranslation.keyboard.ime

import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.offlinetranslation.keyboard.data.SettingsRepository
import com.offlinetranslation.keyboard.keyboard.KeyAction
import com.offlinetranslation.keyboard.keyboard.KeyboardLayer
import com.offlinetranslation.keyboard.keyboard.KeyboardScreen
import com.offlinetranslation.keyboard.translation.Lang
import com.offlinetranslation.keyboard.translation.OfflineTranslationEngine

class OfflineTranslationIME : InputMethodService() {

    private lateinit var settings: SettingsRepository
    private lateinit var engine: OfflineTranslationEngine
    private var imeLifecycleOwner: ImeLifecycleOwner? = null

    // Compose state, held here so the service can drive it directly.
    private var layerState = mutableStateOf(KeyboardLayer.BANGLA_LETTERS)
    private var isTranslatingState = mutableStateOf(false)
    private var previewOriginal = mutableStateOf<String?>(null)
    private var previewTranslated = mutableStateOf<String?>(null)

    override fun onCreate() {
        super.onCreate()
        settings = SettingsRepository(this)
        engine = OfflineTranslationEngine(this)
    }

    override fun onCreateInputView(): View {
        val owner = ImeLifecycleOwner().also { imeLifecycleOwner = it }
        owner.performRestore()
        owner.onStart()
        owner.onResume()

        layerState.value = if (settings.defaultLayoutIsBangla) KeyboardLayer.BANGLA_LETTERS else KeyboardLayer.ENGLISH

        val composeView = ComposeView(this).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
            setViewTreeLifecycleOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setContent {
                MaterialTheme {
                    Surface {
                        Column {
                            val original by previewOriginal
                            val translated by previewTranslated
                            if (settings.showOriginalAndTranslated && translated != null) {
                                TranslationPreviewBar(original ?: "", translated ?: "")
                            }
                            val layer by layerState
                            val isTranslating by isTranslatingState
                            KeyboardScreen(
                                layer = layer,
                                isTranslating = isTranslating,
                                onAction = ::handleAction
                            )
                        }
                    }
                }
            }
        }
        return composeView
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        previewOriginal.value = null
        previewTranslated.value = null
    }

    override fun onDestroy() {
        imeLifecycleOwner?.onPause()
        imeLifecycleOwner?.onStop()
        imeLifecycleOwner?.onDestroy()
        super.onDestroy()
    }

    // ---- Key handling -----------------------------------------------------------------

    private fun handleAction(action: KeyAction) {
        maybeHapticFeedback()
        val ic = currentInputConnection
        when (action) {
            is KeyAction.InsertText -> {
                ic?.commitText(action.text, 1)
                previewTranslated.value = null
            }
            KeyAction.Backspace -> ic?.deleteSurroundingText(1, 0)
            KeyAction.Space -> ic?.commitText(" ", 1)
            KeyAction.Enter -> sendEnter(ic)
            KeyAction.SwitchToEnglish -> layerState.value = KeyboardLayer.ENGLISH
            KeyAction.SwitchToBangla -> layerState.value = KeyboardLayer.BANGLA_LETTERS
            KeyAction.SwitchToSymbols -> layerState.value = KeyboardLayer.SYMBOLS
            KeyAction.SwitchToLetters -> layerState.value =
                if (settings.defaultLayoutIsBangla) KeyboardLayer.BANGLA_LETTERS else KeyboardLayer.ENGLISH
            KeyAction.SwitchToEmoji -> layerState.value = KeyboardLayer.EMOJI
            KeyAction.ToggleMatraLayer -> layerState.value =
                if (layerState.value == KeyboardLayer.BANGLA_MATRA) KeyboardLayer.BANGLA_LETTERS
                else KeyboardLayer.BANGLA_MATRA
            KeyAction.Translate -> translateCurrentField()
            KeyAction.NextInputMethod -> switchToNextKeyboard()
            KeyAction.ShiftLayer -> Unit
        }
    }

    private fun sendEnter(ic: InputConnection?) {
        val editorInfo = currentInputEditorInfo
        val action = editorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
        val hasSendOrDone = action != null && action != EditorInfo.IME_ACTION_NONE &&
            editorInfo.imeOptions.and(EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0
        if (hasSendOrDone) {
            ic?.performEditorAction(action!!)
        } else {
            ic?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
    }

    private fun switchToNextKeyboard() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            switchToNextInputMethod(false)
        } else {
            @Suppress("DEPRECATION")
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .switchToNextInputMethod(window.window?.attributes?.token, false)
        }
    }

    /**
     * The headline feature: read the whole current text field, translate it fully offline,
     * and put the translated text back into the same field (WhatsApp/Messenger/Telegram/etc)
     * so the user only has to tap Send. No copy-paste, and nothing leaves the device.
     */
    private fun translateCurrentField() {
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(4000, 0)?.toString() ?: ""
        val after = ic.getTextAfterCursor(4000, 0)?.toString() ?: ""
        val fullText = before + after
        if (fullText.isBlank()) return

        isTranslatingState.value = true
        val target = if (settings.autoDetectLanguage) null else settings.defaultTargetLang
        val result = engine.translate(fullText, target)
        isTranslatingState.value = false

        previewOriginal.value = result.originalText
        previewTranslated.value = result.translatedText

        if (settings.autoInsertTranslation) {
            ic.beginBatchEdit()
            ic.deleteSurroundingText(before.length, after.length)
            ic.commitText(result.translatedText, 1)
            ic.endBatchEdit()
        }
    }

    private fun maybeHapticFeedback() {
        if (!settings.vibrateOnKeyPress) return
        val vibrator = getSystemService(VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(8, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(8)
        }
    }
}

@androidx.compose.runtime.Composable
private fun TranslationPreviewBar(original: String, translated: String) {
    Column(Modifier.fillMaxWidth().padding(8.dp)) {
        Text("মূল: $original", fontSize = 12.sp)
        Text("অনুবাদ: $translated", fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
    }
}
