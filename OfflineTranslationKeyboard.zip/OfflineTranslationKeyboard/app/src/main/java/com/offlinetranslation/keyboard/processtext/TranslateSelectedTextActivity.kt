package com.offlinetranslation.keyboard.processtext

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.offlinetranslation.keyboard.data.SettingsRepository
import com.offlinetranslation.keyboard.translation.OfflineTranslationEngine

/**
 * This is what runs when a user selects text from an incoming WhatsApp/Messenger/Telegram
 * message and taps "Translate" in the system's text-selection menu. It never touches the
 * network — translation happens with the same on-device engine the keyboard uses.
 */
class TranslateSelectedTextActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val selectedText = intent?.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString().orEmpty()
        val readOnly = intent?.getBooleanExtra(Intent.EXTRA_PROCESS_TEXT_READONLY, true) ?: true

        val engine = OfflineTranslationEngine(this)
        val settings = SettingsRepository(this)
        val target = if (settings.autoDetectLanguage) null else settings.defaultTargetLang
        val result = engine.translate(selectedText, target)

        setContent {
            MaterialTheme {
                Surface(tonalElevation = 4.dp) {
                    TranslateDialogContent(
                        original = result.originalText,
                        translated = result.translatedText,
                        allowReplace = !readOnly,
                        onReplace = {
                            val resultIntent = Intent().apply {
                                putExtra(Intent.EXTRA_PROCESS_TEXT, result.translatedText)
                            }
                            setResult(Activity.RESULT_OK, resultIntent)
                            finish()
                        },
                        onClose = { finish() }
                    )
                }
            }
        }
    }
}

@Composable
private fun TranslateDialogContent(
    original: String,
    translated: String,
    allowReplace: Boolean,
    onReplace: () -> Unit,
    onClose: () -> Unit,
) {
    val clipboard: ClipboardManager = LocalClipboardManager.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(20.dp)
    ) {
        Text("অনুবাদ (Translate)", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))

        Text("মূল লেখা", style = MaterialTheme.typography.labelMedium)
        Text(original, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))

        Text("অনুবাদ", style = MaterialTheme.typography.labelMedium)
        Text(translated, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(20.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { clipboard.setText(AnnotatedString(translated)) }) {
                Text("Copy")
            }
            if (allowReplace) {
                Button(onClick = onReplace) { Text("Replace") }
            }
            TextButton(onClick = onClose) { Text("বন্ধ করুন") }
        }
    }
}
