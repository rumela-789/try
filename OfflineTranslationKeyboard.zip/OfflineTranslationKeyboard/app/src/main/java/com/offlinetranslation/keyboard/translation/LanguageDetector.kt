package com.offlinetranslation.keyboard.translation

/**
 * Detects Bangla vs English purely from the Unicode code points present in the text.
 * This is deliberately simple (no model, no assets, zero latency) since Bangla and Latin
 * scripts never overlap in their Unicode ranges, which makes character-range detection
 * reliable for this use case.
 */
object LanguageDetector {

    private val BENGALI_RANGE = 0x0980..0x09FF

    fun detect(text: String): Lang {
        var bengaliCount = 0
        var latinCount = 0
        for (ch in text) {
            val cp = ch.code
            when {
                cp in BENGALI_RANGE -> bengaliCount++
                (ch in 'a'..'z') || (ch in 'A'..'Z') -> latinCount++
            }
        }
        return if (bengaliCount >= latinCount && bengaliCount > 0) Lang.BANGLA
        else if (latinCount > 0) Lang.ENGLISH
        else Lang.ENGLISH // default fallback when text has no letters (numbers/punctuation only)
    }
}
