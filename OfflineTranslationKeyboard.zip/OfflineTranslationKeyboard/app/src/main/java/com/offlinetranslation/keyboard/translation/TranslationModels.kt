package com.offlinetranslation.keyboard.translation

/** Supported languages. Add new entries here as more offline packs are bundled. */
enum class Lang(val code: String, val displayName: String) {
    BANGLA("bn", "বাংলা"),
    ENGLISH("en", "English");

    companion object {
        fun other(of: Lang): Lang = if (of == BANGLA) ENGLISH else BANGLA
        fun fromCode(code: String): Lang = entries.firstOrNull { it.code == code } ?: ENGLISH
    }
}

data class TranslationResult(
    val originalText: String,
    val translatedText: String,
    val detectedLang: Lang,
    val targetLang: Lang,
)

/**
 * Contract for a translation engine. The MVP implementation (OfflineTranslationEngine) is
 * fully on-device and dictionary/rule based. It is intentionally isolated behind this
 * interface so a future, larger on-device neural model (e.g. a bundled TensorFlow Lite /
 * ONNX seq2seq model) can be swapped in later without touching any caller.
 */
interface TranslationEngine {
    fun isReady(): Boolean
    fun detectLanguage(text: String): Lang
    fun translate(text: String, targetLang: Lang? = null): TranslationResult
}
