package com.offlinetranslation.keyboard.ui.screens

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.offlinetranslation.keyboard.R
import com.offlinetranslation.keyboard.ime.OfflineTranslationIME

private fun isKeyboardEnabled(context: Context): Boolean {
    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    val id = "${context.packageName}/${OfflineTranslationIME::class.java.name}"
    return imm.enabledInputMethodList.any { it.id == id }
}

@Composable
fun HomeScreen() {
    val context = LocalContext.current
    var enabled by remember { mutableStateOf(isKeyboardEnabled(context)) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Icon(Icons.Filled.Keyboard, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(12.dp))
        Text(stringResource(R.string.home_title), style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(4.dp))
        Text(stringResource(R.string.home_subtitle), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Spacer(Modifier.height(24.dp))

        StatusRow(enabled)

        Spacer(Modifier.height(20.dp))

        SetupStepCard(
            title = stringResource(R.string.setup_step_1_title),
            desc = stringResource(R.string.setup_step_1_desc),
            buttonLabel = stringResource(R.string.open_keyboard_settings),
            onClick = {
                context.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        )

        Spacer(Modifier.height(12.dp))

        SetupStepCard(
            title = stringResource(R.string.setup_step_2_title),
            desc = stringResource(R.string.setup_step_2_desc),
            buttonLabel = stringResource(R.string.choose_input_method),
            onClick = {
                val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
                enabled = isKeyboardEnabled(context)
            }
        )
    }
}

@Composable
private fun StatusRow(enabled: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            if (enabled) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (enabled) Color(0xFF0F9D58) else MaterialTheme.colorScheme.outline
        )
        Spacer(Modifier.width(8.dp))
        Text(
            if (enabled) stringResource(R.string.keyboard_enabled_yes) else stringResource(R.string.keyboard_enabled_no),
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
private fun SetupStepCard(title: String, desc: String, buttonLabel: String, onClick: () -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(desc, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onClick) { Text(buttonLabel) }
        }
    }
}
