package com.offlinetranslation.keyboard.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.offlinetranslation.keyboard.navigation.AppNavHost
import com.offlinetranslation.keyboard.ui.theme.OfflineTranslationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            OfflineTranslationTheme {
                Surface(modifier = Modifier) {
                    AppNavHost()
                }
            }
        }
    }
}
